# Stable Eye: entrega para Replit

Este paquete contiene una encuesta independiente de Typeform. Lee este archivo y `README.md` antes de integrarla.

## Instrucción para pegar en Replit Agent

> Integra la encuesta de este ZIP en mi web. Conserva las preguntas, opciones, orden, bifurcaciones, logo, tipografía, colores y transiciones que incluye. Hay cuatro perfiles y cada recorrido tiene cinco pantallas. El archivo `public/survey.json` contiene los textos y la lógica originales. No conviertas la encuesta en un formulario largo. Usa el frontend de `public/` y conecta el endpoint POST `/api/submit` de `server.mjs` al servidor de mi proyecto. Si mi proyecto ya tiene servidor, adapta el handler a ese framework en vez de reemplazar mi aplicación. Conserva la validación en servidor, el destinatario fijo founder@stable-eye.co, el manejo de errores y las claves de idempotencia. Publica la encuesta en `/encuesta/` o intégrala mediante un iframe. Configura RESEND_API_KEY y MAIL_FROM mediante Secrets, nunca en el navegador. Necesito un remitente con dominio verificado en Resend. No muestres la pantalla de éxito cuando falten credenciales o falle el envío. Ejecuta `npm test` y comprueba los cuatro perfiles, móvil, escritorio y navegación por teclado. El envío real queda pendiente hasta configurar los secretos. No reemplaces ni elimines partes de mi web ajenas a la encuesta.

## Activar el correo

1. Crea una API key de envío en Resend y verifica un dominio que controles (por ejemplo, `stable-eye.co`). Añade los registros DNS que Resend indique.
2. En Secrets de Replit añade `RESEND_API_KEY` con esa clave.
3. Añade `MAIL_FROM` con un remitente de ese dominio: `Stable Eye <encuestas@stable-eye.co>` es un ejemplo, y requiere verificar antes el dominio.
4. Ejecuta y publica la aplicación con un servidor Node.js. Una publicación exclusivamente estática no puede enviar estos correos.
5. Haz una respuesta de prueba identificada como prueba y comprueba su llegada a `founder@stable-eye.co`. Revisa también spam y el registro de entrega en Resend.

El destinatario ya está fijado en el servidor. La API key no se incluye en el ZIP, porque pertenece a tu cuenta. No hace falta acceso a tu buzón para enviar mediante Resend.

Documentación: [enviar email](https://resend.com/docs/api-reference/emails/send-email), [verificar dominio](https://resend.com/docs/dashboard/domains/introduction), [idempotencia](https://resend.com/docs/dashboard/emails/idempotency-keys).
