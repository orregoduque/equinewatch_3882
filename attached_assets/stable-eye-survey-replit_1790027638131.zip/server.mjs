import { createServer } from 'node:http';
import { readFile } from 'node:fs/promises';
import { fileURLToPath } from 'node:url';
import { resolve, extname, sep } from 'node:path';
import { createHash } from 'node:crypto';
import { getPath, validateAnswers, answerRows } from './public/survey-core.js';

const root = fileURLToPath(new URL('./public/', import.meta.url));
export const survey = JSON.parse(await readFile(new URL('./public/survey.json', import.meta.url), 'utf8'));
export const RECIPIENT = 'founder@stable-eye.co';
const mime = { '.html': 'text/html; charset=utf-8', '.js': 'text/javascript; charset=utf-8', '.css': 'text/css; charset=utf-8', '.json': 'application/json; charset=utf-8', '.png': 'image/png', '.woff2': 'font/woff2' };
const escape = text => String(text).replace(/[&<>"']/g, char => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' })[char]);

export function buildEmail(answers, submissionId, from) {
  const rows = answerRows(survey, answers);
  const contact = answers[survey.fields.at(-1).ref];
  const profile = rows[0][1];
  return {
    from, to: [RECIPIENT], reply_to: contact.email,
    subject: `Stable Eye — Nueva encuesta: ${profile}`,
    text: `Nueva respuesta a la encuesta Stable Eye\nReferencia: ${submissionId}\n\n` + rows.map(([q, a]) => `${q}\n${a}`).join('\n\n'),
    html: `<div style="font-family:Arial,sans-serif;color:#2a222b;max-width:720px"><h1>Stable Eye</h1><h2>Nueva respuesta a la encuesta</h2><p>Referencia: ${escape(submissionId)}</p><table style="border-collapse:collapse;width:100%">${rows.map(([q, a]) => `<tr><th style="padding:14px 10px;border-bottom:1px solid #ddd;text-align:left;vertical-align:top">${escape(q)}</th><td style="padding:14px 10px;border-bottom:1px solid #ddd;white-space:pre-wrap">${escape(a)}</td></tr>`).join('')}</table><p>Puedes responder a este correo para contactar al participante.</p></div>`
  };
}
function json(res, status, data) {
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Cache-Control': 'no-store' });
  res.end(JSON.stringify(data));
}
async function readJson(req) {
  let size = 0;
  const chunks = [];
  for await (const chunk of req) {
    size += chunk.length;
    if (size > 16384) { const error = new Error('La respuesta es demasiado grande.'); error.status = 413; throw error; }
    chunks.push(chunk);
  }
  try { return JSON.parse(Buffer.concat(chunks).toString('utf8')); }
  catch { const error = new Error('JSON inválido.'); error.status = 400; throw error; }
}

export function createApp({ env = process.env, fetchImpl = fetch } = {}) {
  const requests = new Map();
  const completed = new Map();
  const pending = new Map();
  let globalWindow = { start: Date.now(), count: 0 };
  const turnstileEnabled = Boolean(env.TURNSTILE_SITE_KEY && env.TURNSTILE_SECRET_KEY);
  const turnstileMisconfigured = Boolean(env.TURNSTILE_SITE_KEY) !== Boolean(env.TURNSTILE_SECRET_KEY);
  return createServer(async (req, res) => {
    res.setHeader('X-Content-Type-Options', 'nosniff');
    res.setHeader('Referrer-Policy', 'strict-origin-when-cross-origin');
    res.setHeader('Content-Security-Policy', "default-src 'self'; script-src 'self' https://challenges.cloudflare.com; style-src 'self' 'unsafe-inline'; img-src 'self' data:; font-src 'self'; connect-src 'self' https://challenges.cloudflare.com; frame-src https://challenges.cloudflare.com; object-src 'none'; base-uri 'self'; form-action 'self'");
    try {
      let path = new URL(req.url, 'http://localhost').pathname;
      if (path === '/encuesta') { res.writeHead(302, { Location: '/encuesta/' }); return res.end(); }
      if (path.startsWith('/encuesta/')) path = path.slice('/encuesta'.length);
      if (path === '/api/config' && req.method === 'GET') return json(res, 200, { turnstileSiteKey: turnstileEnabled ? env.TURNSTILE_SITE_KEY : '' });
      if (path === '/api/health' && req.method === 'GET') return json(res, 200, { ok: true, emailConfigured: Boolean(env.RESEND_API_KEY && env.MAIL_FROM && !turnstileMisconfigured) });
      if (path === '/api/submit') {
        if (req.method !== 'POST') { res.setHeader('Allow', 'POST'); return json(res, 405, { error: 'Método no permitido.' }); }
        if (!req.headers['content-type']?.startsWith('application/json')) return json(res, 415, { error: 'Se requiere JSON.' });
        // JSON + no CORS prevents other websites from submitting via the browser.
        if (req.headers['sec-fetch-site'] === 'cross-site') return json(res, 403, { error: 'Origen no permitido.' });
        const now = Date.now();
        for (const [key, entry] of requests) if (entry.until < now) requests.delete(key);
        for (const [key, entry] of completed) if (entry.until < now) completed.delete(key);
        // Do not trust client-supplied X-Forwarded-For. Shared proxy traffic also has a global cap.
        const ip = req.socket.remoteAddress || 'unknown';
        const rate = requests.get(ip) || { count: 0, until: now + 15 * 60_000 };
        rate.count++;
        requests.set(ip, rate);
        if (rate.count > 120) { res.setHeader('Retry-After', '900'); return json(res, 429, { error: 'Demasiados intentos. Vuelve a intentarlo más tarde.' }); }
        const body = await readJson(req);
        if (!body || typeof body !== 'object' || Array.isArray(body)) return json(res, 400, { error: 'Solicitud inválida.' });
        if (body.website) return json(res, 400, { error: 'No se pudo verificar el envío.' });
        if (!/^[a-f0-9]{8}-[a-f0-9]{4}-4[a-f0-9]{3}-[89ab][a-f0-9]{3}-[a-f0-9]{12}$/i.test(body.submissionId || '')) return json(res, 400, { error: 'Identificador de envío inválido.' });
        let answers;
        try { answers = validateAnswers(survey, body.answers); }
        catch (error) { return json(res, 400, { error: error.message }); }
        const digest = createHash('sha256').update(JSON.stringify(answers)).digest('hex');
        const previous = completed.get(body.submissionId);
        if (previous) return json(res, previous.digest === digest ? 200 : 409, previous.digest === digest ? { ok: true } : { error: 'El envío ya existe con otras respuestas. Recarga la página.' });
        const inflight = pending.get(body.submissionId);
        if (inflight) return json(res, 409, { error: 'El envío está en curso. Espera unos segundos y reintenta.' });
        if (!env.RESEND_API_KEY || !env.MAIL_FROM || turnstileMisconfigured) return json(res, 503, { error: 'El envío de correo aún no está configurado. Contacta con Stable Eye o vuelve a intentarlo más tarde.' });
        if (turnstileEnabled) {
          if (typeof body.turnstileToken !== 'string' || !body.turnstileToken || body.turnstileToken.length > 2048) return json(res, 400, { error: 'Completa la verificación antes de enviar.' });
          const verification = await fetchImpl('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
            method: 'POST', headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ secret: env.TURNSTILE_SECRET_KEY, response: body.turnstileToken }), signal: AbortSignal.timeout(10000)
          });
          if (!verification.ok || !(await verification.json()).success) return json(res, 400, { error: 'La verificación ha caducado. Vuelve a intentarlo.' });
        }
        if (now - globalWindow.start > 3600_000) globalWindow = { start: now, count: 0 };
        if (globalWindow.count >= 100) { res.setHeader('Retry-After', '3600'); return json(res, 429, { error: 'El servicio ha alcanzado su límite temporal. Vuelve a intentarlo más tarde.' }); }
        globalWindow.count++;
        pending.set(body.submissionId, digest);
        try {
          const response = await fetchImpl('https://api.resend.com/emails', {
            method: 'POST', headers: {
              Authorization: `Bearer ${env.RESEND_API_KEY}`, 'Content-Type': 'application/json',
              'Idempotency-Key': `stable-eye/${body.submissionId}`
            },
            body: JSON.stringify(buildEmail(answers, body.submissionId, env.MAIL_FROM)), signal: AbortSignal.timeout(15000)
          });
          if (!response.ok) {
            console.error('Email provider rejected request. HTTP', response.status);
            return json(res, 502, { error: 'No se pudo enviar el correo. Tus respuestas siguen aquí; vuelve a intentarlo.' });
          }
          const result = await response.json();
          if (!result.id) return json(res, 502, { error: 'No se pudo confirmar el envío. Vuelve a intentarlo.' });
          completed.set(body.submissionId, { digest, until: Date.now() + 24 * 3600_000 });
          return json(res, 200, { ok: true });
        } finally { pending.delete(body.submissionId); }
      }
      if (!['GET', 'HEAD'].includes(req.method)) return json(res, 405, { error: 'Método no permitido.' });
      const decoded = decodeURIComponent(path);
      if (decoded.includes('\0') || decoded.split(/[\\/]/).some(p => p.startsWith('.'))) return json(res, 404, { error: 'No encontrado.' });
      const filename = resolve(root, '.' + (decoded === '/' ? '/index.html' : decoded));
      if (!filename.startsWith(root.endsWith(sep) ? root : root + sep)) return json(res, 404, { error: 'No encontrado.' });
      let data;
      try { data = await readFile(filename); } catch { return json(res, 404, { error: 'No encontrado.' }); }
      res.writeHead(200, { 'Content-Type': mime[extname(filename)] || 'application/octet-stream', 'Cache-Control': 'no-cache' });
      return res.end(req.method === 'HEAD' ? undefined : data);
    } catch (error) {
      if (res.headersSent || res.destroyed) return;
      console.error('Request failed:', error.name);
      json(res, error.status || 503, { error: error.status ? error.message : 'No se pudo completar el envío. Vuelve a intentarlo.' });
    }
  });
}

if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url)) {
  const port = Number(process.env.PORT) || 3000;
  createApp().listen(port, '0.0.0.0', () => {
    console.log(`Stable Eye disponible en http://localhost:${port}`);
    if (!process.env.RESEND_API_KEY || !process.env.MAIL_FROM) console.log('Configura RESEND_API_KEY y MAIL_FROM para activar el envío real.');
  });
}
