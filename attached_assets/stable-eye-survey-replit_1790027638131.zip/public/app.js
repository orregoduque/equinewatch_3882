import { getPath, validateAnswers } from './survey-core.js';

const stage = document.querySelector('#stage');
const progress = document.querySelector('#progress');
const navigation = document.querySelector('#navigation');
const previous = document.querySelector('#previous');
const next = document.querySelector('#next');
const storageKey = 'stable-eye-survey-v1';
let survey, config, index = -1, answers = {}, busy = false, moving = false, selectionTimer;
let submissionId = crypto.randomUUID(), turnstileToken = '', widgetId;
const reducedMotion = matchMedia('(prefers-reduced-motion: reduce)');

function el(tag, props = {}, children = []) {
  const node = document.createElement(tag);
  for (const [key, value] of Object.entries(props)) {
    if (key === 'class') node.className = value;
    else if (key === 'text') node.textContent = value;
    else if (key.startsWith('on')) node.addEventListener(key.slice(2), value);
    else node.setAttribute(key, value);
  }
  node.append(...children);
  return node;
}
function save() {
  // Only non-contact answers are retained for this browser tab. Contact stays in memory.
  const safe = Object.fromEntries(Object.entries(answers).filter(([ref]) => ref !== survey.fields.at(-1).ref));
  try { sessionStorage.setItem(storageKey, JSON.stringify({ answers: safe, index: Math.min(index, 4) })); } catch {}
}
function changed(ref, value) {
  answers[ref] = value;
  submissionId = crypto.randomUUID();
  save();
}
function current() { return getPath(survey, answers)[index]; }
function showError(message) {
  let error = stage.querySelector('.error');
  if (!error) {
    error = el('p', { class: 'error', role: 'alert', tabindex: '-1' });
    stage.querySelector('.screen').append(error);
  }
  error.textContent = message;
  error.focus();
}
function updateNavigation() {
  const count = getPath(survey, answers).length;
  const visible = index >= 0 && index < count;
  navigation.hidden = progress.hidden = !visible;
  previous.disabled = index <= 0 || busy || moving;
  next.disabled = index >= count - 1 || busy || moving;
  progress.setAttribute('aria-valuenow', String(Math.max(index, 0)));
  progress.setAttribute('aria-valuemax', String(count));
  progress.firstElementChild.style.width = `${Math.max(index, 0) / count * 100}%`;
}
async function go(target) {
  if (busy || moving) return;
  clearTimeout(selectionTimer);
  const direction = target >= index ? 1 : -1;
  moving = true;
  updateNavigation();
  const old = stage.firstElementChild;
  if (!reducedMotion.matches && old) {
    await old.animate([{ opacity: 1, transform: 'translateY(0)' }, { opacity: 0, transform: `translateY(${-direction * 65}px)` }], { duration: 170, easing: 'ease-in' }).finished;
  }
  index = target;
  render();
  save();
  window.scrollTo({ top: 0, behavior: 'instant' });
  if (!reducedMotion.matches) {
    await stage.firstElementChild.animate([{ opacity: 0, transform: `translateY(${direction * 80}px)` }, { opacity: 1, transform: 'translateY(0)' }], { duration: 330, easing: 'cubic-bezier(.2,.7,.2,1)' }).finished;
  }
  moving = false;
  updateNavigation();
  stage.querySelector('h1')?.focus({ preventScroll: true });
}
function welcome() {
  const data = survey.welcome_screens[0];
  return el('section', { class: 'screen welcome' }, [
    el('img', { src: './assets/logo.png', alt: 'Stable Eye', width: '332', height: '257' }),
    el('h1', { text: data.title, tabindex: '-1' }),
    el('p', { text: data.properties.description }),
    el('button', { class: 'primary', text: data.properties.button_text, onclick: () => go(0) }),
    el('span', { class: 'time', text: '◷ Takes 2 minutes' })
  ]);
}
function choose(field, value, button) {
  if (busy || moving) return;
  clearTimeout(selectionTimer);
  const multi = field.properties.allow_multiple_selection;
  if (multi) {
    const selected = new Set(answers[field.ref] || []);
    selected.has(value) ? selected.delete(value) : selected.add(value);
    changed(field.ref, [...selected]);
  } else {
    changed(field.ref, value);
    if (field === survey.fields[0]) {
      const valid = new Set(getPath(survey, answers).map(f => f.ref));
      for (const ref of Object.keys(answers)) if (!valid.has(ref)) delete answers[ref];
      save();
    }
  }
  stage.querySelectorAll('.choice').forEach(item => {
    const selected = multi ? answers[field.ref].includes(item.dataset.value) : String(value) === item.dataset.value;
    item.classList.toggle('selected', selected);
    item.setAttribute('aria-checked', String(selected));
  });
  if (!multi) selectionTimer = setTimeout(() => go(index + 1), reducedMotion.matches ? 50 : 280);
}
function choices(field) {
  const scale = field.type === 'opinion_scale';
  const multi = field.properties.allow_multiple_selection;
  const options = scale ? Array.from({ length: field.properties.steps }, (_, i) => ({ ref: i + 1, label: String(i + 1) })) : field.properties.choices;
  const group = el('div', { class: scale ? 'scale' : 'choices', role: multi ? 'group' : 'radiogroup', 'aria-labelledby': 'question-title' });
  options.forEach((option, i) => {
    const selected = multi ? (answers[field.ref] || []).includes(option.ref) : answers[field.ref] === option.ref;
    const button = el('button', {
      type: 'button', class: `choice${selected ? ' selected' : ''}`, role: multi ? 'checkbox' : 'radio',
      'aria-label': option.label, 'aria-checked': String(selected), 'data-value': option.ref,
      onclick: event => choose(field, option.ref, event.currentTarget)
    }, scale ? [el('span', { text: option.label })] : [
      el('span', { class: 'key', text: String.fromCharCode(65 + i), 'aria-hidden': 'true' }),
      el('span', { text: option.label }), el('span', { class: 'tick', text: '✓', 'aria-hidden': 'true' })
    ]);
    group.append(button);
  });
  if (!scale) return group;
  return el('div', {}, [group, el('div', { class: 'scale-labels' }, [
    el('span', { text: field.properties.labels.left }), el('span', { text: field.properties.labels.right })
  ])]);
}
function contact(field) {
  const value = answers[field.ref] || {};
  const form = el('form', { id: 'contact-form', onsubmit: event => { event.preventDefault(); submit(); } });
  const grid = el('div', { class: 'contact-grid' });
  const labels = { first_name: 'First name', last_name: 'Last name', phone_number: 'Phone number', email: 'Email' };
  const placeholders = { first_name: 'Enter your first name', last_name: 'Enter your last name', phone_number: '+57 300 123 4567', email: 'Enter your email address' };
  const autocomplete = { first_name: 'given-name', last_name: 'family-name', phone_number: 'tel', email: 'email' };
  for (const sub of field.properties.fields) {
    const key = sub.subfield_key;
    const input = el('input', {
      id: key, name: key, class: 'text-input', type: key === 'email' ? 'email' : key === 'phone_number' ? 'tel' : 'text',
      placeholder: placeholders[key], autocomplete: autocomplete[key], maxlength: '254',
      oninput: event => changed(field.ref, { ...(answers[field.ref] || {}), [key]: event.target.value })
    });
    if (sub.validations.required) input.required = true;
    input.value = value[key] || '';
    grid.append(el('label', { for: key, class: ['email', 'phone_number'].includes(key) ? 'wide' : '' }, [
      el('span', { text: labels[key] + (sub.validations.required ? ' *' : '') }), input
    ]));
  }
  form.append(grid, el('label', { class: 'trap', 'aria-hidden': 'true' }, [
    el('span', { text: 'Website' }), el('input', { name: 'website', id: 'website', tabindex: '-1', autocomplete: 'off' })
  ]));
  if (config.turnstileSiteKey) form.append(el('div', { id: 'turnstile', class: 'actions' }));
  form.append(el('div', { class: 'actions' }, [el('button', { class: 'primary', type: 'submit', id: 'submit-button', text: 'Submit' })]),
    el('p', { class: 'privacy', text: 'Tus respuestas y datos de contacto se enviarán a Stable Eye para conocer tu experiencia y contactarte.' }));
  return form;
}
function render() {
  if (widgetId !== undefined && window.turnstile) window.turnstile.remove(widgetId);
  widgetId = undefined;
  turnstileToken = '';
  stage.replaceChildren();
  if (index === -1) stage.append(welcome());
  else {
    const field = current();
    if (!field) return;
    const screen = el('section', { class: 'screen', 'aria-labelledby': 'question-title' });
    const heading = el('h1', { id: 'question-title', tabindex: '-1', text: field.title + (field.type === 'contact_info' ? ' *' : '') });
    const head = el('div', { class: 'question-head' }, [el('span', { class: 'number', text: String(index + 1), 'aria-label': `Question ${index + 1} of 5` }), heading]);
    if (field.properties.allow_multiple_selection) head.append(el('p', { class: 'hint', text: 'Choose as many as you like' }));
    screen.append(head);
    if (field.type === 'contact_info') screen.append(contact(field));
    else {
      if (['multiple_choice', 'opinion_scale'].includes(field.type)) screen.append(choices(field));
      else {
        const input = el('input', { class: 'text-input', type: 'text', maxlength: '500', 'aria-labelledby': 'question-title', placeholder: 'Type your answer here...', oninput: event => changed(field.ref, event.target.value) });
        input.value = answers[field.ref] || '';
        screen.append(input);
      }
      screen.append(el('div', { class: 'actions' }, [
        el('button', { class: 'primary', text: 'OK', onclick: () => go(index + 1) }),
        el('span', { class: 'enter-hint', text: 'press Enter ↵' })
      ]));
    }
    stage.append(screen);
    if (field.type === 'contact_info' && config.turnstileSiteKey) mountTurnstile();
  }
  updateNavigation();
}
async function mountTurnstile() {
  try {
    if (!window.turnstile) await new Promise((resolve, reject) => {
      const script = document.createElement('script');
      script.src = 'https://challenges.cloudflare.com/turnstile/v0/api.js?render=explicit';
      script.onload = resolve;
      script.onerror = reject;
      document.head.append(script);
    });
    if (!document.querySelector('#turnstile')) return;
    widgetId = window.turnstile.render('#turnstile', {
      sitekey: config.turnstileSiteKey, callback: token => { turnstileToken = token; },
      'expired-callback': () => { turnstileToken = ''; }, 'error-callback': () => { turnstileToken = ''; }
    });
  } catch { showError('No se pudo cargar la verificación. Recarga la página para intentarlo otra vez.'); }
}
async function submit() {
  if (busy || moving) return;
  const form = stage.querySelector('form');
  if (!form.reportValidity()) return;
  let clean;
  try { clean = validateAnswers(survey, answers); } catch (error) { showError(error.message); return; }
  if (config.turnstileSiteKey && !turnstileToken) return showError('Completa la verificación antes de enviar.');
  busy = true;
  updateNavigation();
  stage.querySelector('.error')?.remove();
  const button = stage.querySelector('#submit-button');
  button.disabled = true;
  form.querySelectorAll('input').forEach(input => { input.disabled = true; });
  button.replaceChildren(el('span', { class: 'sending', 'aria-hidden': 'true' }), 'Enviando…');
  try {
    const response = await fetch('./api/submit', {
      method: 'POST', headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ answers: clean, submissionId, website: form.querySelector('#website').value, turnstileToken }),
      signal: AbortSignal.timeout(25000)
    });
    const result = await response.json();
    if (!response.ok || !result.ok) throw new Error(result.error || 'No se pudo enviar la encuesta. Inténtalo otra vez.');
    try { sessionStorage.removeItem(storageKey); } catch {}
    answers = {};
    navigation.hidden = progress.hidden = true;
    stage.replaceChildren(el('section', { class: 'screen success' }, [
      el('div', { class: 'success-mark', text: '✓', 'aria-hidden': 'true' }),
      el('h1', { tabindex: '-1', text: '¡Gracias por tu tiempo!' }),
      el('p', { text: 'Hemos recibido tus respuestas.\nTu experiencia nos ayuda a construir Stable Eye.' })
    ]));
    index = 5;
    stage.querySelector('h1').focus();
  } catch (error) {
    showError(error.name === 'TimeoutError' ? 'El envío está tardando más de lo esperado. Reintenta sin cambiar tus respuestas para evitar duplicados.' : error.message === 'Failed to fetch' ? 'No hay conexión. Tus respuestas siguen aquí; vuelve a intentarlo.' : error.message);
    if (widgetId !== undefined && window.turnstile) { window.turnstile.reset(widgetId); turnstileToken = ''; }
    form.querySelectorAll('input').forEach(input => { input.disabled = false; });
    button.disabled = false;
    button.textContent = 'Reintentar envío';
  } finally { busy = false; updateNavigation(); }
}
previous.addEventListener('click', () => go(index - 1));
next.addEventListener('click', () => go(index + 1));
document.addEventListener('keydown', event => {
  if (!survey || busy || moving || index >= 5 || event.altKey || event.ctrlKey || event.metaKey) return;
  const typing = ['INPUT', 'TEXTAREA', 'SELECT'].includes(event.target.tagName);
  if (event.key === 'Enter' && event.target.tagName !== 'BUTTON') {
    event.preventDefault();
    if (index === 4) stage.querySelector('form')?.requestSubmit();
    else go(index + 1);
  } else if (!typing && index >= 0) {
    const buttons = [...stage.querySelectorAll('.choice')];
    const position = current()?.type === 'opinion_scale' ? Number(event.key) - 1 : event.key.toUpperCase().charCodeAt(0) - 65;
    if (event.key.length === 1 && buttons[position]) { event.preventDefault(); buttons[position].click(); }
    else if (event.key === 'ArrowUp' && index > 0) { event.preventDefault(); go(index - 1); }
    else if (event.key === 'ArrowDown' && index < 4) { event.preventDefault(); go(index + 1); }
  }
});

try {
  [survey, config] = await Promise.all(['./survey.json', './api/config'].map(async url => {
    const response = await fetch(url);
    if (!response.ok) throw new Error('No se pudo cargar la encuesta.');
    return response.json();
  }));
  try {
    const saved = JSON.parse(sessionStorage.getItem(storageKey));
    if (saved?.answers && typeof saved.answers === 'object' && !Array.isArray(saved.answers)) {
      // Validate draft shape with a synthetic contact, then remove that contact.
      const contactRef = survey.fields.at(-1).ref;
      const clean = validateAnswers(survey, { ...saved.answers, [contactRef]: { first_name: 'draft', last_name: '', phone_number: '+5700000000', email: 'draft@example.com' } });
      delete clean[contactRef];
      answers = clean;
      if (Number.isInteger(saved.index) && saved.index >= -1 && saved.index <= 4) index = saved.index;
    }
  } catch {}
  render();
} catch {
  stage.replaceChildren(el('p', { role: 'alert', text: 'No se pudo cargar la encuesta. Comprueba la conexión y recarga la página.' }));
}
