// Shared between the browser, server and tests. Source references are preserved.
export function getPath(survey, answers = {}) {
  const fields = survey.fields;
  const path = [];
  let field = fields[0];
  while (field && !path.includes(field)) {
    path.push(field);
    const rule = survey.logic.find(rule => rule.ref === field.ref);
    const action = rule?.actions.find(({ condition }) => {
      if (condition.op === 'always') return true;
      if (condition.op !== 'is') return false;
      const [source, choice] = condition.vars;
      return answers[source.value] === choice.value;
    });
    field = action
      ? fields.find(item => item.ref === action.details.to.value)
      : fields[fields.indexOf(field) + 1];
  }
  return path;
}

export function validateAnswers(survey, input) {
  if (!input || typeof input !== 'object' || Array.isArray(input)) throw new Error('Respuestas inválidas.');
  const cleaned = {};
  for (const field of getPath(survey, input)) {
    const value = input[field.ref];
    if (field.type === 'contact_info') {
      if (!value || typeof value !== 'object' || Array.isArray(value)) throw new Error('Completa tus datos de contacto.');
      cleaned[field.ref] = {};
      for (const sub of field.properties.fields) {
        const raw = value[sub.subfield_key] ?? '';
        if (typeof raw !== 'string' || raw.length > 254) throw new Error('Datos de contacto inválidos.');
        const text = raw.trim();
        if (sub.validations.required && !text) throw new Error('Completa los datos de contacto obligatorios.');
        if (sub.type === 'email' && !/^[^\s@<>]+@[^\s@<>]+\.[^\s@<>]+$/.test(text)) throw new Error('Escribe un correo electrónico válido.');
        if (sub.type === 'phone_number' && !/^\+[1-9][\d\s().-]{6,24}$/.test(text)) throw new Error('Escribe el teléfono con prefijo internacional (por ejemplo +57).');
        cleaned[field.ref][sub.subfield_key] = text;
      }
    } else if (field.type === 'multiple_choice') {
      const choices = field.properties.choices.map(choice => choice.ref);
      if (field.properties.allow_multiple_selection) {
        const list = value ?? [];
        if (!Array.isArray(list) || list.length > choices.length || list.some(v => !choices.includes(v))) throw new Error('Selección inválida.');
        cleaned[field.ref] = [...new Set(list)];
      } else {
        if (value != null && value !== '' && !choices.includes(value)) throw new Error('Selección inválida.');
        cleaned[field.ref] = value || '';
      }
    } else if (field.type === 'opinion_scale') {
      if (value != null && value !== '' && (!Number.isInteger(value) || value < 1 || value > field.properties.steps)) throw new Error('Escala inválida.');
      cleaned[field.ref] = value ?? '';
    } else {
      if (value != null && (typeof value !== 'string' || value.length > 500)) throw new Error('Texto inválido (máximo 500 caracteres).');
      cleaned[field.ref] = value?.trim() ?? '';
    }
  }
  return cleaned;
}

export function answerRows(survey, answers) {
  return getPath(survey, answers).flatMap(field => {
    const value = answers[field.ref];
    if (field.type === 'contact_info') return field.properties.fields.map(sub => [sub.title, value[sub.subfield_key] || 'Sin respuesta']);
    let text = value;
    if (field.type === 'multiple_choice') {
      const refs = Array.isArray(value) ? value : [value];
      text = field.properties.choices.filter(c => refs.includes(c.ref)).map(c => c.label).join(', ');
    }
    return [[field.title, String(text || 'Sin respuesta')]];
  });
}
