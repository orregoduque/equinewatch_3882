# Encuesta Stable Eye

Réplica independiente basada en la encuesta pública https://form.typeform.com/to/xTfx0D6P, consultada el 21 de septiembre de 2026. El ZIP se puede entregar a Replit Agent junto con `INSTRUCCIONES-REPLIT.md`.

## Ejecutar

Requiere Node.js 22 o superior. No necesita dependencias npm ni build.

```sh
npm start
```

Abre `http://localhost:3000` o `http://localhost:3000/encuesta/`. Para desarrollo con recarga del servidor: `npm run dev`. Para verificar: `npm test`.

La interfaz funciona sin claves. El envío devuelve un error explícito hasta configurar `RESEND_API_KEY` y `MAIL_FROM`. En local, copia `.env.example` como `.env` y rellena los valores. En Replit, utiliza Secrets. No publiques `.env`.

## Contenido y fidelidad

- Se conservan literalmente las 14 preguntas/bloques del original, opciones, selección múltiple, escala 1–5 y reglas de salto. Cada participante ve perfil + tres preguntas de su perfil + contacto, cinco pantallas en total.
- Perfiles: propietario, administrador, groom y veterinario. Si se omite el perfil, se sigue el recorrido de propietario, igual que la lógica original. Las preguntas de encuesta son opcionales; nombre, teléfono y correo son obligatorios. Last name es opcional.
- Los textos de bienvenida y el logo proceden del original. Tema Pearl White, fondo `#FAFAFA`, texto/botón `#2A222B`, tipografía Inter incluida localmente con su licencia.
- Las animaciones están recreadas mediante desplazamiento vertical, fundido, resaltado de opciones y barra de progreso; no se incluye el motor propietario de Typeform y no se garantiza una coincidencia exacta de cada fotograma o duración. Se respeta la preferencia del sistema de reducir movimiento.
- Se mantienen los rótulos de interfaz que aparecían en inglés en el original: Comenzar, Takes 2 minutes, OK, Choose as many as you like, First name, Last name, Phone number, Email y Submit. Los títulos españoles de los subcampos originales permanecen en los datos y en el correo.
- Diferencias deliberadas: se retiran la marca/promoción de Typeform y su enlace para crear formularios. El final muestra un agradecimiento de Stable Eye. El teléfono usa un campo internacional con ejemplo +57 en vez del selector de banderas. Se añade una nota breve sobre el destino de las respuestas. No se envían respuestas a Typeform.
- El borrador de las preguntas se conserva en sessionStorage durante la pestaña. Los datos de contacto solo se mantienen en memoria y se pierden al recargar. Al cambiar perfil se descartan respuestas de otros recorridos.

`source-form.json` conserva la definición pública original completa como referencia. `public/survey.json` es la fuente de contenido utilizada por cliente y servidor. No cambies refs sin revisar las reglas de salto.

## Integración en una web existente

Opción A: incorporar el código al proyecto. Copia los archivos de `public/` a la ruta de encuesta, sirve también `survey-core.js` y `survey.json`, y adapta los endpoints `/api/config` y `/api/submit` al mismo prefijo. Los fetch y assets del cliente son relativos, así que `/encuesta/` funciona con el servidor incluido. Conserva la barra final. No reemplaces un servidor existente sin adaptar su routing.

Opción B: publica este paquete como aplicación Node.js independiente e inserta un iframe. Copia `embed.html` y reemplaza el dominio de ejemplo por el dominio real de esa aplicación. El servidor no envía X-Frame-Options, por lo que permite incrustarlo. El frontend y el endpoint permanecen en el mismo origen dentro del iframe; no hace falta abrir CORS.

La web anfitriona debe permitir el dominio de la encuesta en su directiva CSP `frame-src`, si tiene una. Si restringes los sitios que pueden incrustar la encuesta, añade en el servidor una directiva CSP `frame-ancestors` con los dominios de tu web. No utilices un iframe de Typeform si quieres que este servidor gestione las respuestas.

## Envío y operación

`POST /api/submit` valida contra las preguntas y opciones conocidas, descarta respuestas ajenas al perfil y envía un correo HTML/texto a **founder@stable-eye.co**. Reply-To apunta al correo del participante. El navegador no puede escoger destinatario, asunto ni HTML. El contenido libre se escapa antes de incluirlo en HTML.

La pantalla de éxito aparece únicamente después de que Resend acepte el correo con un identificador. Eso no garantiza su llegada al buzón: para comprobar entregas o rebotes, utiliza el panel de Resend. No hay base de datos ni archivo local de respuestas. Si el proveedor falla, la interfaz mantiene los datos en memoria y permite reintentar. Conserva las mismas respuestas al reintentar; la idempotencia del proveedor evita duplicados durante su ventana de 24 horas. Un cambio en las respuestas genera un nuevo identificador.

Protección incluida: límite de 16 KB por petición, validación, honeypot, rechazo de peticiones de navegador cross-site, límites temporales en memoria e idempotencia. Los límites por proceso son 120 peticiones por dirección de conexión cada 15 minutos y 100 intentos de envío por hora. Detrás de un proxy, la dirección de conexión puede ser compartida; ajusta estos límites al tráfico esperado. No se confía ciegamente en X-Forwarded-For. En múltiples instancias o tras reinicios los límites locales no son compartidos; para mayor tráfico adapta el rate limiting al proxy o almacén compartido de tu infraestructura.

Opcionalmente configura AMBAS claves `TURNSTILE_SITE_KEY` y `TURNSTILE_SECRET_KEY` para activar Cloudflare Turnstile. Autoriza el dominio donde se publica la encuesta en Turnstile. No configures solo una. Las claves privadas permanecen en el servidor.

`GET /api/health` informa de si las variables de correo están presentes; no valida la clave contra Resend. No se registran respuestas ni claves en consola.

## Archivos

| Archivo | Función |
| --- | --- |
| `INSTRUCCIONES-REPLIT.md` | Prompt listo para Replit y activación del correo |
| `server.mjs` | Servidor estático, validación y envío seguro |
| `public/index.html`, `public/styles.css`, `public/app.js` | Interfaz y animaciones |
| `public/survey.json`, `public/survey-core.js` | Contenido, saltos y validación compartida |
| `public/assets/` | Logo, Inter y licencia |
| `test/survey.test.mjs` | Pruebas de rutas, validación y envío simulado |
| `source-form.json` | Definición pública original para referencia |
| `.env.example`, `.replit`, `package.json` | Configuración |
| `embed.html` | Ejemplo de iframe para tu web |

Las pruebas de correo usan un proveedor simulado: no mandan emails reales. Falta realizar una prueba de entrega real después de configurar los secretos y el remitente verificado.
