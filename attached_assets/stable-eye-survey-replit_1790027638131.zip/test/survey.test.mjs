import test from 'node:test';
import assert from 'node:assert/strict';
import { randomUUID } from 'node:crypto';
import { readFile } from 'node:fs/promises';
import { createApp, survey, buildEmail, RECIPIENT } from '../server.mjs';
import { getPath, validateAnswers } from '../public/survey-core.js';

function sample(profile = 0) {
  const answers = { [survey.fields[0].ref]: survey.fields[0].properties.choices[profile].ref };
  for (const field of getPath(survey, answers).slice(1)) {
    if (field.type === 'contact_info') answers[field.ref] = { first_name: 'Prueba <script>', last_name: '', phone_number: '+57 300 123 4567', email: 'test@example.com' };
    else if (field.type === 'short_text') answers[field.ref] = '3';
    else if (field.type === 'opinion_scale') answers[field.ref] = 4;
    else answers[field.ref] = field.properties.allow_multiple_selection ? field.properties.choices.slice(0, 2).map(c => c.ref) : field.properties.choices[0].ref;
  }
  return answers;
}
async function fixture(t, options = {}) {
  const app = createApp(options);
  await new Promise(resolve => app.listen(0, '127.0.0.1', resolve));
  t.after(() => new Promise(resolve => { app.close(resolve); app.closeAllConnections(); }));
  const base = `http://127.0.0.1:${app.address().port}`;
  return { base, post: (body, headers = {}) => fetch(base + '/api/submit', { method: 'POST', headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(body) }) };
}
const configured = { RESEND_API_KEY: 'test-key', MAIL_FROM: 'Stable Eye <test@example.com>' };

test('published questions, options and branch rules exactly match the source snapshot', async () => {
  const source = JSON.parse(await readFile(new URL('../source-form.json', import.meta.url), 'utf8'));
  assert.deepEqual(survey.fields, source.fields);
  assert.deepEqual(survey.logic, source.logic);
  assert.deepEqual(survey.welcome_screens, source.welcome_screens);
});
for (let i = 0; i < 4; i++) {
  test(`profile ${i + 1} has the correct three questions and contact`, () => {
    const answer = sample(i);
    const actual = getPath(survey, answer).map(f => f.id);
    const expected = [survey.fields[0], ...survey.fields.slice(1 + i * 3, 4 + i * 3), survey.fields.at(-1)].map(f => f.id);
    assert.deepEqual(actual, expected);
    assert.equal(getPath(survey, validateAnswers(survey, answer)).length, 5);
  });
}
test('optional profile falls through to owner branch as in original', () => {
  assert.deepEqual(getPath(survey).map(f => f.id), [0, 1, 2, 3, 13].map(i => survey.fields[i].id));
});
test('server discards answers from a different profile', () => {
  const answers = { ...sample(0), ...sample(2) };
  assert.equal(Object.keys(validateAnswers(survey, answers)).length, 5);
  assert.equal(validateAnswers(survey, answers)[survey.fields[1].ref], undefined);
});
test('required contact and choice validation', () => {
  const answers = sample();
  answers[survey.fields.at(-1).ref].email = 'invalid';
  assert.throws(() => validateAnswers(survey, answers), /correo/);
  answers[survey.fields.at(-1).ref].email = 'test@example.com';
  answers[survey.fields[0].ref] = 'forged-choice';
  assert.throws(() => validateAnswers(survey, answers), /Selección/);
});
test('email fixes the recipient and escapes user content', () => {
  const email = buildEmail(validateAnswers(survey, sample()), randomUUID(), configured.MAIL_FROM);
  assert.deepEqual(email.to, [RECIPIENT]);
  assert.equal(email.reply_to, 'test@example.com');
  assert.ok(email.html.includes('&lt;script&gt;'));
  assert.ok(!email.html.includes('<script>'));
  assert.ok(email.text.includes('Personal del establo, Cámaras'));
});
test('successful submissions call the provider once; retry is idempotent', async t => {
  const calls = [];
  const { post } = await fixture(t, { env: configured, fetchImpl: async (url, options) => {
    calls.push({ url, options });
    return Response.json({ id: 'email-test-id' });
  } });
  const body = { answers: sample(), submissionId: randomUUID(), to: 'attacker@example.com' };
  assert.equal((await post(body)).status, 200);
  assert.equal((await post(body)).status, 200);
  assert.equal(calls.length, 1);
  assert.deepEqual(JSON.parse(calls[0].options.body).to, [RECIPIENT]);
  assert.equal(calls[0].options.headers['Idempotency-Key'], `stable-eye/${body.submissionId}`);
  body.answers[survey.fields[1].ref] = '100';
  assert.equal((await post(body)).status, 409);
});
test('missing credentials returns unavailable, never fake success', async t => {
  const { post } = await fixture(t, { env: {} });
  assert.equal((await post({ answers: sample(), submissionId: randomUUID() })).status, 503);
});
test('provider rejection returns an error and allows retry', async t => {
  let attempts = 0;
  const { post } = await fixture(t, { env: configured, fetchImpl: async () => ++attempts === 1 ? Response.json({ error: 'test' }, { status: 500 }) : Response.json({ id: 'test-id' }) });
  const body = { answers: sample(), submissionId: randomUUID() };
  assert.equal((await post(body)).status, 502);
  assert.equal((await post(body)).status, 200);
});
test('invalid request, honeypot, wrong origin and oversized body are rejected', async t => {
  const { post } = await fixture(t, { env: {} });
  assert.equal((await post(null)).status, 400);
  assert.equal((await post({ website: 'spam' })).status, 400);
  assert.equal((await post({}, { 'sec-fetch-site': 'cross-site' })).status, 403);
  assert.equal((await post({ text: 'x'.repeat(17000) })).status, 413);
});
test('static app works at root and encuesta; private files are not served', async t => {
  const { base } = await fixture(t, { env: {} });
  for (const path of ['/', '/encuesta/', '/encuesta/app.js', '/survey.json', '/assets/logo.png', '/assets/inter-latin.woff2']) {
    assert.equal((await fetch(base + path)).status, 200, path);
  }
  for (const path of ['/.env', '/server.mjs', '/source-form.json', '/%2e%2e%5cserver.mjs']) {
    assert.equal((await fetch(base + path)).status, 404, path);
  }
});
test('optional bot check is verified on the server', async t => {
  const calls = [];
  const { post } = await fixture(t, { env: { ...configured, TURNSTILE_SITE_KEY: 'public-test', TURNSTILE_SECRET_KEY: 'private-test' }, fetchImpl: async url => {
    calls.push(url);
    return Response.json({ success: false });
  } });
  assert.equal((await post({ answers: sample(), submissionId: randomUUID(), turnstileToken: 'invalid' })).status, 400);
  assert.deepEqual(calls, ['https://challenges.cloudflare.com/turnstile/v0/siteverify']);
});
