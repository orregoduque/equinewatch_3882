# Verificación de la entrega

21 de septiembre de 2026.

- `node --test`: 15 pruebas correctas, 0 errores.
- Se cotejaron bienvenida, preguntas, opciones y reglas con la definición pública de Typeform incluida en `source-form.json`.
- Pruebas de los cuatro recorridos y del salto por defecto: todos tienen cinco pantallas.
- Pruebas de campos obligatorios, opciones inválidas, eliminación de respuestas de otros perfiles y escape de HTML.
- Endpoint probado con proveedor de correo simulado: aceptación, fallo, reintento, idempotencia y destinatario fijo.
- Acceso estático probado tanto en `/` como en `/encuesta/`; archivos privados no accesibles desde la web.
- Navegador: bienvenida, avance automático, selección múltiple y escala del groom; recorrido veterinario completo hasta agradecimiento con proveedor simulado.
- Navegador: sin credenciales, aparece error de configuración y se conservan los datos en la pantalla para reintentar.
- Vista móvil de 390 × 844: contacto y agradecimiento sin desbordamiento horizontal; comprobado también en escritorio.

No se envió ningún email real. Falta configurar los Secrets de Replit, verificar el dominio remitente y comprobar una entrega real a founder@stable-eye.co. Las animaciones se recrean; no se ha realizado una comparación fotograma a fotograma con Typeform.
